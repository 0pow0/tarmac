from setuptools import setup

setup(name='gym_starcraft',
      version='0.0.1',
      install_requires=['gym','numpy', 'torchcraft']  # And any other dependencies foo needs
)  